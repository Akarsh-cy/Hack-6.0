import { LiquidMetalIDCard } from "@/components/liquid-metal-id-card"

export default function Page() {
  return (
    <main className="min-h-screen bg-black flex items-center justify-center p-8">
      {/* Subtle ambient glow */}
      <div
        className="fixed inset-0 opacity-20 pointer-events-none"
        style={{
          background: `
            radial-gradient(ellipse at 50% 50%, rgba(255, 255, 255, 0.03) 0%, transparent 70%)
          `,
        }}
      />

      <div className="relative z-10">
        <LiquidMetalIDCard name="Vix Clotet" role="v0 Ambassador" idNumber="V0-2024-AMB-001" />
      </div>
    </main>
  )
}
